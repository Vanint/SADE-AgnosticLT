from .resnet_cifar import *
from .resnet import *
